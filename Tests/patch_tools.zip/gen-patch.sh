#!/bin/sh
bsdiff_cmd=./bsdiff
bspatch_cmd=./bspatch
diff_base_file="weex.js"
diff_info_file="patch_info.txt"

is_restore="false"
if [[ -d $1 ]]; then
	lastpath=$(basename $1)
	#最后面传一个-r则表示恢复pach文件
	if [[ $2 == "-r" ]]; then
		is_restore="true"		
	fi
else
	echo "传入待处理文件夹路径"
	exit 0
fi

output_path=./output_patch
if [[ $is_restore == "true" ]]; then
	output_path=./output_restore
fi

rootdir=${lastpath}
workspace=${output_path}/${rootdir}
#删除目录
if [[ -d ${output_path} ]]; then
	rm -rf ${workspace}
else
	mkdir -p ${output_path}
fi
cp -r $1 ${output_path}/

if [[ -f ${workspace}/${diff_base_file} ]]; then
	echo "基准文件: ${workspace}/${diff_base_file}"
else
	echo "未找到基准文件: ${workspace}/${diff_base_file}"
	exit 0
fi

gen_diff_file(){
	local folder_path=$1
	for file_a in ${folder_path}/*
	do  
	    local temp_file=`basename $file_a`
	    if [ -d $file_a ];then
	    	gen_diff_file ${folder_path}/$temp_file
	    else
			if echo "$temp_file" | grep -q -E '\.js$';then
				if [ $temp_file != $diff_base_file ];then					
					local oldfile=${workspace}/${diff_base_file}
					local newfile=${folder_path}/${temp_file}
					local patchfile=${folder_path}/"${temp_file}.patch"
					$bsdiff_cmd $oldfile $newfile $patchfile

					local newfilesize=$(ls -l $newfile | awk '{ print $5 }')
					local patchfilesize=$(ls -l $patchfile | awk '{ print $5 }')
					# if [ $newfilesize -gt $patchfilesize ]; then
						local old_size=$(du -sh $newfile | awk '{ print $1 }')
						local new_size=$(du -sh $patchfile | awk '{ print $1 }')
						echo "处理文件: $newfile 大小: $old_size -> $new_size"
			    		mv ${patchfile} ${newfile}
			    		rm -rf ${patchfile}
			    		echo "${newfile/$workspace\//}\c" >> ${workspace}/${diff_info_file}
			    		echo "|\c" >> ${workspace}/${diff_info_file}
			    	# else
			    		# rm -rf ${patchfile}
					# fi					
				fi				
			fi
	    fi
	done
}

#处理了所有js文件，原则上应该是处理patch_info文件中有的文件列表
restore_diff_file(){
	local folder_path=$1
	for file_a in ${folder_path}/*
	do  
	    local temp_file=`basename $file_a`
	    if [ -d $file_a ];then
	    	restore_diff_file ${folder_path}/$temp_file
	    else
			if echo "$temp_file" | grep -q -E '\.js$';then
				if [ $temp_file != $diff_base_file ];then
					local oldfile=${workspace}/${diff_base_file}					
					local patchfile=${folder_path}/${temp_file}
					local newfile="${patchfile}.tmp"					
					$bspatch_cmd $oldfile $newfile $patchfile
		    		rm -rf ${patchfile}
		    		mv $newfile $patchfile
		    		rm -rf $newfile
		    		echo "处理文件: $patchfile"
				fi				
			fi
	    fi
	done
}

old_size=$(du -sh $workspace | awk '{ print $1 }')
#处理文件名带空格问题
oldIFS=$IFS
IFS=$'\n'

if [[ $is_restore == "true" ]]; then
	restore_diff_file ${workspace}
	rm -rf ${workspace}/${diff_info_file}
else
	echo "${diff_base_file}\c" >> ${workspace}/${diff_info_file}
	echo "|\c" >> ${workspace}/${diff_info_file}
	gen_diff_file ${workspace}
fi

IFS=$oldIFS
new_size=$(du -sh $workspace | awk '{ print $1 }')
echo "总大小: $old_size -> $new_size"

